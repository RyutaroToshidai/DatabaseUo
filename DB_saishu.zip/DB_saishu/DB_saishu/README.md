# github-projects-sample
Sample Python Project for TCU DB class final practice.

1. Check out this project.
2. Edit .env file in accordance with each student's prostgres UserName and Password.
3. In command tool, move to same directory of app.py.
4. In command tool, python app.py
5. In browser, open "http://127.0.0.1:5000"
